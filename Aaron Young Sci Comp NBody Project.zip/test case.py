# -*- coding: utf-8 -*-
"""
Created on Thu Nov 17 13:02:45 2022

@author: Aaron
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
import time 

'''
defining some constants
'''

G = 6.67 * 10**(-11) #constant can be changed to 6.67x10^-11 for realism
secsinyear = 3.154*10**7

t = np.arange(0,5 * secsinyear, secsinyear/(365))

AU = 1.496 * 10**11

M0 = 1.989*10**30

Day1 = 60*60*24

star_x = -0.5 * AU
star_y  = 0 * AU
SMass1 = 1 * M0

Star2_x = 0.5 * AU
Star2_y = 0 * AU
SMass2 = 1 * M0



Masses = np.array([SMass1,SMass2])


NumofObjects = len(Masses)

'''
the initial values are the x,y,Vx,Vy of the two bodies
'''

Invals = np.array([star_x,star_y,0, -15000,Star2_x,Star2_y,0,15000])


'''
defining a function to work out the acceleration
'''
def Accel(Pos1x,Pos2x,Pos1y,Pos2y,Mass):
    r1 = Pos1x - Pos2x
    r2 = Pos1y - Pos2y

    R = np.sqrt(r1**2 + r2**2)
    Acc = -G * Mass * r1 / R**3

    return Acc

'''
defining the function that will be used for the odeint cycle
'''
def Func(vals,dt):
    '''
    defining an empty array that will be filled with the new velocities and accelerations
    '''
    NewVals = np.zeros(NumofObjects * 4)
    
    '''
    the outer loop gets the first object, the inner loop then works out the acceleration contribution from each GPE with all other objects
    NewVals[i+2] and NewVals[i+3] sends the x and y positions for the ith and jth object into the accel function to get a return of the new acceleration for the ith object
    NewVals[i] and NewVals[i+1] get the x and y velocities passed into them
    '''
    
    for i in range (0,NumofObjects * 4 -1,4):

        for j in range(0,NumofObjects * 4 - 1,4):
            if i != j:
                k = int(j/4)
                NewVals[i+2] += Accel(vals[i],vals[j], vals[i+1], vals[j+1], Masses[k])
                NewVals[i+3] += Accel(vals[i+1],vals[j+1], vals[i], vals[j], Masses[k])
                
   
        NewVals[i] = vals[i+2]
        NewVals[i+1] = vals[i+3]
    
   

    return NewVals
start_time = time.time()
'''
All the postiitons and velocities at each time step are stored in the 2D array FinalVals
'''
FinalVals = odeint(Func,Invals,t, rtol = 1e-10, atol = 1e-10)

end_time = time.time()
print('Time taken = ', end_time - start_time)

Fig1 = plt.figure()
plt.subplots_adjust(wspace=1, hspace=0.5, top=0.85, left = 0.15)
plt.suptitle('Test Case')
ax1 = Fig1.add_subplot(2,1,1)
plt.xlabel('x [AU]')
plt.ylabel('y [AU]')

ax2 = Fig1.add_subplot(2,1,2)


colours = np.array(['r','b'])
for i in range(0,NumofObjects * 4 -1, 4):
    
    ax1.plot((FinalVals[:,i]) / AU,(FinalVals[:,i+1] )/ AU ,colours[i//4])
    ax1.axis('scaled')
    ax1.legend(('Body 1','Body 2'))



ax2.plot(t/secsinyear,FinalVals[:,0]/AU,'r')
ax2.plot(t/secsinyear,FinalVals[:,4]/AU,'b')

ax2.axis('scaled')
plt.xlabel('t [yr]')
plt.ylabel('x [AU]')


'''
calculating the change in energy
'''

TotalE = 0

for i in range (0,NumofObjects * 4 -1,4):
    V = np.sqrt((FinalVals[:,i + 2])**2 + (FinalVals[:,i + 3])**2)
    m = int(i/4)
    TotalE += 0.5 * Masses[m] * V**2
    for j in range(i+4,NumofObjects * 4 - 3,4):
            R  = np.sqrt((FinalVals[:,i] - FinalVals[:,j])**2 + (FinalVals[:,i+1] - FinalVals[:,j+1])**2) 
            n=int(j/4)
            TotalE += -G * Masses[m] * Masses[n] / R
            
deltaE = (TotalE - TotalE[0] ) / TotalE[0]

Fig3 = plt.figure()
plt.plot(t/secsinyear, deltaE)
plt.xlabel('t [yr]')
plt.ylabel('$\Delta E$')



