# -*- coding: utf-8 -*-
"""
Created on Thu Nov 17 13:02:45 2022

@author: Aaron
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
import time 


'''
defining some constants
'''
G = 6.67 * 10**(-11) 
secsinyear = 3.154*10**7

t = np.arange(0,250 * secsinyear, secsinyear/(365/4)) #creating an array of time values from 0 to 12 years in steps of a quarter of a year

AU = 1.496 * 10**11

M0 = 1.989*10**30
#ly = 9.46 * 10**15
Day1 = 60*60*24


'''
creating a class that can make any of the large objects like a planet/sun
'''
class SpaceObj:
    def __init__(self,x,Period,Mass):
        self.x = x * AU
        self.y = 0
        self.Vx = 0
        self.Vy = self.x * 2 * np.pi / (Period * Day1)
        self.mass = Mass
    

Sun = SpaceObj(0,1,1 * M0)
Mercury = SpaceObj(0.4,88,3.3e23)
Venus = SpaceObj(0.7,224.7,4.87e24)
Earth = SpaceObj(0.98,365.2,5.97e24)
Mars = SpaceObj(1.5,687,6.42e23)
Jupiter = SpaceObj(5.2,4331,1.9e27)
Saturn = SpaceObj(9.5,10747,5.68e26)
Uranus = SpaceObj(19,30589,8.68e25)
Neptune = SpaceObj(30,59800,1.02e26)
Pluto = SpaceObj(39.5,90560,1.31e22)


MyObj = np.array([Sun,Mercury,Venus,Earth,Mars,Jupiter,Saturn,Uranus,Neptune,Pluto]) #storing all of the objects in one array

'''
creating arrays that will store the x,y,Vx,Vy vals of all the objects, also creating one for the masses
'''
Invals = np.array([])
Masses = np.array([])

NumofObjects = len(MyObj)
for i in range(0,len(MyObj)):
    Invals = np.append(Invals,MyObj[i].x)
    Invals = np.append(Invals,MyObj[i].y)
    Invals = np.append(Invals,MyObj[i].Vx)
    Invals = np.append(Invals,MyObj[i].Vy)
    Masses = np.append(Masses,MyObj[i].mass)

'''
defining a function to work out the acceleration
'''
def Accel(Pos1x,Pos2x,Pos1y,Pos2y,Mass):
    r1 = Pos1x - Pos2x
    r2 = Pos1y - Pos2y

    R = np.sqrt(r1**2 + r2**2)
    Acc = -G * Mass * r1 / R**3

    return Acc
    
'''
defining the function that will be used for the odeint cycle
'''
    
def Func(vals,dt):
    '''
    defining an empty array that will be filled with the new velocities and accelerations
    '''
    NewVals = np.zeros(NumofObjects * 4)
    
    '''
    B is an array of the indexs of the x pos for each object except for the ith object so that it doesnt do caluclations with itslef
    iarr is an array of the same shape as B but filled with the i value so that it is the index for the xpos of the ith object
    NewValsx and NewValsy send the x and y positions for the ith and every other object into the accel function to get a return of an array of the acceleration contributions for the ith object
    NewVals[i+2] and NewVals[i+3] add the columns of NewValsx and NewValsy to get the total accel for the ith object
    NewVals[i] and NewVals[i+1] get the x and y velocities passed into them
    '''
   
    for i in range (0,NumofObjects * 4 -1,4):
        B = np.arange(0,NumofObjects*4,4, dtype = int)
        B = np.delete(B,int(i/4))
        iarr = np.ones(shape = np.shape(B), dtype = int ) * i

        NewValsx = Accel(vals[iarr],vals[B], vals[iarr+1], vals[B+1], Masses[B//4]) 
        NewValsy = Accel(vals[iarr+1],vals[B+1], vals[iarr], vals[B], Masses[B//4])
        
        NewVals[i+2] = np.sum(NewValsx, axis = 0)
        NewVals[i+3] = np.sum(NewValsy, axis = 0)
   
        NewVals[i] = vals[i+2]
        NewVals[i+1] = vals[i+3]
           
    return NewVals

start_time = time.time()
 
'''
All the postiitons and velocities at each time step are stored in the 2D array FinalVals
'''
FinalVals = odeint(Func,Invals,t, rtol = 1e-12, atol = 1e-12)

end_time = time.time()
print('Time taken = ', end_time - start_time)

Fig1 = plt.figure(figsize = (12,7))
plt.subplots_adjust(wspace=0.6, hspace=0.8, top=0.85, left = 0.1)
plt.suptitle('Our Solar System simulated for 12 years')
ax1 = Fig1.add_subplot(211)
ax2 = Fig1.add_subplot(212)


colours = np.array(['y*','r','m','g','b','r','c','y','b','k','c','bx'])

'''
loops in steps of 4 so that the ith value is the x pos and the i + 1 value is the y pos
i//4 is which object is being plotted so it knows what colour to plot it as
'''
for i in range(0,NumofObjects * 4 -1, 4):
    
    ax1.plot((FinalVals[:,i]- FinalVals[:,0]) / AU,(FinalVals[:,i+1] - FinalVals[:,1] )/ AU ,colours[i//4])
    
#plt.axis('scaled')
ax1.set_xlabel('x [AU]')
ax1.set_ylabel('y [AU]')
'''
fancybox and shadow are aestetics
bbox_to_anchor moves the legend off of the plot and into the middle of the figure
'''
ax1.legend(('Sun','Mercury', 'Venus', ' Earth','Mars','Jupiter','Saturn','Uranus','Neptune','Pluto'),fancybox = True, shadow = True, bbox_to_anchor=(1,1.25))



TotalE = 0
'''
calculating the change in energy, each object needs the KE but only need to work out the GPE for each pair once
'''
for i in range (0,NumofObjects * 4 -1,4):
    V = np.sqrt((FinalVals[:,i + 2])**2 + (FinalVals[:,i + 3])**2)
    TotalE += 0.5 * Masses[i//4] * V**2
    for j in range(i+4,NumofObjects * 4 - 3,4):
            R  = np.sqrt((FinalVals[:,i] - FinalVals[:,j])**2 + (FinalVals[:,i+1] - FinalVals[:,j+1])**2) 
            TotalE += -G * Masses[i//4] * Masses[j//4] / R
            
deltaE = (TotalE - TotalE[0] ) / TotalE[0]

ax2.plot(t/secsinyear, deltaE)
ax2.set_xlabel('Time [yr]')
ax2.set_ylabel('$\Delta E$')